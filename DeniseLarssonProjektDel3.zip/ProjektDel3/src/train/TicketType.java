package train;

public enum TicketType {
    DAY,
    MONTH
}